const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
    const browser = await puppeteer.launch({ headless: false });
    const page = await browser.newPage();

    const sessionFile = "session.json";

    // Cek apakah sudah ada sesi sebelumnya
    if (fs.existsSync(sessionFile)) {
        console.log("🔄 Memuat sesi yang tersimpan...");
        const sessionData = JSON.parse(fs.readFileSync(sessionFile, 'utf-8'));
        await page.setCookie(...sessionData);
    }

    console.log("🌍 Membuka Telegram Web...");
    await page.goto("https://web.telegram.org/");
    await page.waitForTimeout(5000);

    // Tunggu hingga login selesai
    await page.waitForSelector('.chatlist', { timeout: 60000 }).catch(() => {
        console.log("❌ Belum login. Silakan login secara manual!");
        process.exit(1);
    });

    console.log("✅ Login berhasil. Menyimpan sesi...");
    
    // Simpan sesi (cookies)
    const cookies = await page.cookies();
    fs.writeFileSync(sessionFile, JSON.stringify(cookies, null, 2));

    console.log("💾 Sesi berhasil disimpan!");
    await browser.close();
})();
