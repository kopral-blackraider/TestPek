const puppeteer = require('puppeteer');
const fs = require('fs');
require('dotenv').config();

const login = require('./modules/login'); // Memanggil script login.js dari folder modules

(async () => {
    try {
        console.log("[INFO] Memulai proses login...");
        await login(); // Menjalankan fungsi login dari login.js
        console.log("[INFO] Login selesai.");
    } catch (error) {
        console.error("[ERROR] Terjadi kesalahan saat login:", error);
    }
})();

const TELEGRAM_LOGIN_URL = 'https://web.telegram.org/k/';
const SESSION_FILE_PATH = 'session.json';

async function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function loginTelegram() {
    const browser = await puppeteer.launch({
        headless: false,  // Atur false agar bisa melihat prosesnya
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();

    // **Coba load session jika ada**
    if (fs.existsSync(SESSION_FILE_PATH)) {
        const session = JSON.parse(fs.readFileSync(SESSION_FILE_PATH));
        await page.setCookie(...session);
        await page.goto(TELEGRAM_LOGIN_URL);
        await delay(5000); // Tunggu agar halaman termuat
        console.log("✅ Sudah login, langsung lanjut...");
        return browser;
    }

    // **Masuk ke halaman login**
    await page.goto(TELEGRAM_LOGIN_URL);
    await delay(3000); // Beri waktu load halaman

    // **Masukkan nomor telepon**
    await page.waitForSelector('input[type="tel"]', { timeout: 10000 });
    await page.type('input[type="tel"]', process.env.TELEGRAM_USERNAME, { delay: 200 });
    await delay(2000);
    await page.keyboard.press('Enter');

    // Tunggu halaman kode OTP
  try {
    await page.waitForSelector('input[type="number"]', { timeout: 15000 });
    console.log("⚠️ Masukkan kode OTP yang dikirim via Telegram atau SMS:");

    // Menunggu input OTP dari user
    const readline = require("readline");
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question("Masukkan kode OTP: ", async function(otp) {
        await page.type('input[type="number"]', otp, { delay: 200 });
        await page.keyboard.press('Enter');
        rl.close();
    });

    await delay(5000); // Tunggu halaman selesai loading
} catch (error) {
    console.log("✅ Tidak perlu OTP, lanjut...");
}

    // **Simpan sesi setelah berhasil login**
    await delay(5000);
    const cookies = await page.cookies();
    fs.writeFileSync(SESSION_FILE_PATH, JSON.stringify(cookies));
    console.log("✅ Sesi login tersimpan!");

    return browser;
}

(async () => {
    try {
        const browser = await loginTelegram();
        await delay(5000);
        await browser.close();
    } catch (error) {
        console.log("❌ Login gagal, coba lagi dalam 5 menit...", error);
        await delay(5 * 60 * 1000);
        loginTelegram();
    }
})();
