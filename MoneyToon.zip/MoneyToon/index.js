const login = require('./modules/login'); // Memanggil script login.js dari folder modules

(async () => {
    try {
        console.log("[INFO] Memulai proses login...");
        await login(); // Menjalankan fungsi login dari login.js
        console.log("[INFO] Login selesai.");
    } catch (error) {
        console.error("[ERROR] Terjadi kesalahan saat login:", error);
    }
})();